const cookieParser = require('cookie-parser');
const path = require("path");
const sqlite3 = require('sqlite3').verbose();
const fs = require("fs");
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
//за реквиры отчитываться не обязан, тем более перед собой :)

const e404 = (res) =>{res.redirect('err/404')}
const e400 = (res) =>{res.redirect('err/400')}
const e409 = (res) =>{res.redirect('err/409')}
const e500 = (res) =>{res.redirect('err/500')}
const e401 = (res) =>{res.redirect('err/401')}

console.log("Ready to work");

app.use(bodyParser.urlencoded({ extended: true })); // ДЖСОН парсер
app.use(cookieParser()); // куки парсер

const db = new sqlite3.Database('database.db', (err) => {
  if (err) {
    console.error(err.message);
  } else {
    console.log('Connected to the database.');
  }
});



db.run(`CREATE TABLE IF NOT EXISTS "users" (
	"id"	INTEGER,
	"name"	TEXT NOT NULL,
	"email"	TEXT UNIQUE,
	"password"	BLOB NOT NULL,
	"birthday"	DATE,
	"gender"	BLOB,
	"description"	TEXT DEFAULT 'null',
	PRIMARY KEY("id" AUTOINCREMENT)
);`)
//Не трогать, убъет!

app.get('err/info', (req, res) => {
  res.status(200).send(`document.getElementById('info').innerHTML = '${req.cookies.error}'`);
})



app.post('/register', async (req, res) => {
  const { name, email, password, birthday, gender } = req.body; // при изменениии формы, ошибки возникают именно тут!

  db.run(`INSERT INTO users (name, email, password, birthday, gender) 
          VALUES (?, ?, ?, ?, ?)`,
          [name, email, password, birthday, gender], (err) => {
    if (err) {
      console.error(err.message);
      res.status(500).cookie('error', err.message);
      e500(res)
    } else {
      res.status(200).redirect("/");
    }
  });
});

app.post('/login_r', (req, res) => {
  try{
    const { email, password } = req.body;
    db.get(`SELECT * FROM users WHERE email = ? AND password = ?`, [email, password], (err, row) => {
      console.log(email, password);
      if (err) {
        console.error(err.message);
        res.status(500).cookie('error', err.message)
        e500(res)
      } else if (!row) {
        res.status(401).cookie('error', err.message);
        e401()
      } else {
        res.cookie('id', row.id); // Если забудешь, зачем ты писал кукисы, отвечаю - НАДА
        res.status(200).redirect("/profile");
      }
    });
  }catch{
    res.status(500).redirect('/login')
  }
});

app.get('/sqlite-data', async (req, res) => {
  console.log('try to get info to profile: '+req.cookies.id);
  db.all(`SELECT * FROM users WHERE id = ${req.cookies.id}`, (error, rows) => {
    const row = rows[0]
    if (error) {
      console.error(error);
      res.status(500).cookie('error', err.message);
      e500(res)
    } else {
      const html = `
      <div class="user-profile">
        <h2>User Profile</h2>
        <ul>
          <li><span>ID:</span> ${row.id}</li>
          <li><span>Name:</span> ${row.name}</li>
          <li><span>Email:</span> ${row.email}</li>
          <li><span>Birthday:</span> ${row.birthday}</li>
          <li><span>Gender:</span> ${row.gender}</li>
          <li><span>Description:</span> ${row.description}</li>
          <li>
            <span>Change description:</span>
            <form action="/description" method="post">
              <input type="text" name="description" id="des"> <br/>
              <input type="submit" value="Submit">  
            </form>
          </li>
        </ul>
      </div>`
      res.send('document.getElementById("user").innerHTML = `'+html+'`;')
    }
  });
});

app.get('/sqlite-data/:id', async (req, res) => {
  const id = req.params.id;
  console.log('try to get info to profile: '+ id);
  db.all(`SELECT * FROM users WHERE id = ${id}`, (error, rows) => {
    const row = rows[0]
    if (error) {
      console.error(error);
      res.status(500).cookie('error', err.message);
      e500(res)
    } else {
      const html = `
      <div class="user-profile">
        <h2>User Profile</h2>
        <ul>
          <li><span>ID:</span> ${row.id}</li>
          <li><span>Name:</span> ${row.name}</li>
          <li><span>Email:</span> ${row.email}</li>
          <li><span>Birthday:</span> ${row.birthday}</li>
          <li><span>Gender:</span> ${row.gender}</li>
          <li><span>Description:</span> ${row.description}</li>
        </ul>
      </div>`
      res.send('document.getElementById("user").innerHTML = `'+html+'`;')
    }
  });
});

app.post('/description', (req, res) => {
  const description = req.body.description;

  // Update the description in the database
  db.run(`UPDATE users SET description = ? WHERE id = ${req.cookies.id}`, [description], function(err) {
    if (err) {
      console.error(err.message);
      res.status(500).cookie('error', err.message);
      e500(res)
    } else {
      console.log(`Row(s) updated: ${this.changes}`);
      res.status(200).redirect('/profile');
    }
  });
});
//API

app.get('/api/users/:email/:password/:id/:type', (req, res) => {
  const userId = req.params.id;
  const type = req.params.type;
  const email = req.params.email;
  const password = req.params.password;
  db.get(`SELECT * FROM users WHERE email = ? AND password = ?`, [email, password], (err, row) => {
    console.log(email, password);
    if (err) {
      console.error(err.message);
      res.status(500).send(err.message);
    } else if (!row) {
      res.status(401).send('wrong email or password');
    } else {
      
      db.get(`SELECT `+type+` FROM users WHERE id = `+userId, (err, row) =>{
        if (err) {
          console.error(err.message);
          res.status(500).send('Server error');
        }
        else if (!row) {
          console.log('User not found');
          res.status(401).send('You need to be logged in to see this page.');
        }
        else {
          console.log(row)
          res.status(200).send(row)
        }
      })
    }
  });
})

app.get('/api/users/:email/:password/:id', (req, res) => {
  const userId = req.params.id;
  const email = req.params.email;
  const password = req.params.password;
  db.get(`SELECT * FROM users WHERE email = ? AND password = ?`, [email, password], (err, row) => {
    console.log(email, password);
    if (err) {
      console.error(err.message);
      res.status(500).send(err.message);
    } else if (!row) {
      res.status(401).send('wrong email or password');
    } else {
      db.get(`SELECT * FROM users WHERE id = `+userId, (err, row) =>{
        if (err) {
          console.error(err.message);
          res.status(500).send('Server error');
        }
        else if (!row) {
          res.status(401).send('You need to be logged in to see this page.');
        }
        else {
          db.get('SELECT * FROM users WHERE id = ' + userId, (err, row) => {
            if (err) {
              console.error(err.message);
              res.status(500).send('Server error');
            }
            else if (!row) {
              console.log('User not found');
              res.status(401).send('You need to be logged in to see this page.');
            }
            else {
              console.log(row.id);
              res.status(200).send(row)
            }
          });
        }
      })
    }
  });
})

// server main
app.use(async (req, res) => {
  if (!req.cookies.id){
    res.cookie('id', 0, {httpOnly: true });
  }
  let filePath = path.join(__dirname, 'public', req.url === '/' ? 'index.html' : req.url)
  const ext = path.extname(filePath)
  let contentType = 'text/html'

  switch (ext) {
    case '.css':
      contentType = 'text/css'
      break
    case '.js':
      contentType = 'text/javascript'
      break
    default:
      contentType = 'text/html'
  }

  if (!ext) {
    filePath += '.html'
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      fs.readFile(path.join(__dirname, 'public/err', '404.html'), (error, data) => {
        if (error) {
          res.status(500).cookie("error" ,error.message);
          e500(res)
        } else {
          res.status(404).cookie('error' ,'Can not find file ' + filePath)
        }
      })
    } else {
      res.writeHead(200, {
        'Content-Type': contentType
      })
      res.end(content)
    }
  })
})


// Start the server
const port = process.env.PORT || 1945;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
