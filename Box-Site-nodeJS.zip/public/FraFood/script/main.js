const OnClick = {
    a: () =>{
        window.open("index.html", "_self")
    },
    b: () =>{
        window.open("second.html", "_self")
    },
    c: () =>{
        window.open("thrid.html", "_self")
    }
}

const tolite = () =>{window.open("lite.html", "_self")}