const boxeng = {
    low_v: function(){
        window.open('https://github.com/ArtemidaGre/box-engine/tree/15959628004eaa56022c625b8352af9c9d92140c', '_blanc')
        console.log('git ML has been opened')
    },
    mid_v: function(){
        window.open('https://github.com/ArtemidaGre/box-engine/tree/3ddd9ee9ea22226fa47b33c6c9a7776d0d7ab828', '_blanc')
        console.log('git MM has been opened')    
    },
    max_v: function(){
        window.open('https://github.com/ArtemidaGre/box-engine', '_blanc')
        console.log('git MM has been opened')
    }
}