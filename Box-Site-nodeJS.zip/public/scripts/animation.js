const anime = require('animejs');

var anime = anime({
    targets: '#div',
    translateX: 250,
    rotate: '1turn',
    backgroundColor: '#FFF',
    duration: 800
  });