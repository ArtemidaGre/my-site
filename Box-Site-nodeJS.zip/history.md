### 0.0.1 / 02.02.2023
==================
  * started work
  * installed express
  * removed first errors
    - noCode
    - i hadn't have any errors now :(
    - Du bist giftig, ach so giftig
      Gestochen, als ich schlief
      Und der Stachel steckt so tief

### 1.0.0 / 01.04.2023
==================
  * server now on express
  * add working database
  * async :)