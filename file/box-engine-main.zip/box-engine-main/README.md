# box-engine
hello there, its developer!
this engine can be used in console games.

read licence in engine files, please:)
