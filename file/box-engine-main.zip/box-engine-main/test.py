from engine import *

game.new_battle(100, 100, 10, 11, 0.9, 0.95, "враг ебать")